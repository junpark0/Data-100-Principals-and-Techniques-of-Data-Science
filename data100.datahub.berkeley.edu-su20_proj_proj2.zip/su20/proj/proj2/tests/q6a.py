test = {   'name': 'q6a',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> zero_predictor_fp >= 0\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> zero_predictor_fn >= 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
