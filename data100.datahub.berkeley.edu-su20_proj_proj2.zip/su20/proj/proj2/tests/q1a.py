test = {   'name': 'q1a',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> original_training_data.isnull().sum().sum() == 0\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
