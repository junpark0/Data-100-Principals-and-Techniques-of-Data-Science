test = {   'name': 'q4',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> X_train.shape == (7513, 5)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.array_equal(np.unique(X_train), np.array([0, 1])) # X matrix should consist of only 0 or 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.array_equal(np.unique(Y_train), np.array([0, 1])) # y vector should consist of only 0 or 1\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
