test = {   'name': 'q6b',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> zero_predictor_acc >= 0\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> zero_predictor_recall >= 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
